import json
import gzip
from operator import index
import os
import sys

class PostingList:
    def __init__(self, pID, sID, sNum, p, sf, pf):
        self.playId = pID
        self.sceneId = sID
        self.sceneNum = sNum
        self.pos = p
        self.sceneFreq = sf
        self.playFreq = pf

def indexer(inputFile):
    map = {}

    file = gzip.open(inputFile, "rt", encoding="utf-8")
    scenes = json.loads(file.read())
    file.close()

    sceneList = scenes["corpus"]

    for index in range(0, len(sceneList)):
        list = sceneList[index]["text"].split()
        for i in range(0, len(list)):
            if(not list[i] in map.keys()):
                map[list[i]] = [PostingList(sceneList[index]["playId"], sceneList[index]["sceneId"], sceneList[index]["sceneNum"],  i, 0, 0)]
            else:
                map[list[i]].append(PostingList(sceneList[index]["playId"], sceneList[index]["sceneId"], sceneList[index]["sceneNum"],  i, 0, 0))
    return map

def process_query(invertedIndex, playscene, AndOr, terms):
    ret = []

    if(playscene == "play"):
        if(AndOr == "or"):
            for term in terms:
                if(len(term.split(" ")) > 1):                    
                    init = []
                    phrase = term.split(" ")
                    playId = [p.playId for p in invertedIndex[phrase[0]]]
                    pos = [p.pos for p in invertedIndex[phrase[0]]]

                    if(len(init) == 0):
                        for i in range(0, len(playId)):
                            init.append([playId[i], pos[i]])

                    for i in range(1, len(phrase)):
                        curr = []
                        playId = [p.playId for p in invertedIndex[phrase[i]]]
                        pos = [p.pos for p in invertedIndex[phrase[i]]]

                        for index in range(0, len(playId)):
                            curr.append([playId[index], pos[index]-i])
                            
                        init = set([(i[0], i[1]) for i in init]) & set([(i[0], i[1]) for i in curr])

                    list = [i[0] for i in init]
                    
                    if(len(prev) == 0):
                        prev = list
                    else:
                        prev = [i for i in prev if i in list] 
                else:
                    list = invertedIndex[term]
                    for i in range(0, len(list)):
                        if(list[i].playId not in ret):
                            ret.append(list[i].playId)
        elif(AndOr == "and"):
            prev = []
            for term in terms:
                if(len(term.split(" ")) > 1):                    
                    init = []
                    phrase = term.split(" ")
                    playId = [p.playId for p in invertedIndex[phrase[0]]]
                    pos = [p.pos for p in invertedIndex[phrase[0]]]

                    if(len(init) == 0):
                        for i in range(0, len(playId)):
                            init.append([playId[i], pos[i]])

                    for i in range(1, len(phrase)):
                        curr = []
                        playId = [p.playId for p in invertedIndex[phrase[i]]]
                        pos = [p.pos for p in invertedIndex[phrase[i]]]

                        for index in range(0, len(playId)):
                            curr.append([playId[index], pos[index]-i])
                            
                        init = set([(i[0], i[1]) for i in init]) & set([(i[0], i[1]) for i in curr])

                    list = [i[0] for i in init]
                    
                    if(len(prev) == 0):
                        prev = list
                    else:
                        prev = [i for i in prev if i in list]                       
                else:
                    list = [i.playId for i in invertedIndex[term]]
                    if(len(prev) == 0):
                        prev = list
                    else:
                        prev = [i for i in prev if i in list]
            
            for item in prev:
                if(item not in ret):
                    ret.append(item)
    elif(playscene == "scene"):
        if(AndOr == "or"):
            for term in terms:
                if(len(term.split(" ")) > 1):                    
                    init = []
                    phrase = term.split(" ")
                    sceneId = [p.sceneId for p in invertedIndex[phrase[0]]]
                    pos = [p.pos for p in invertedIndex[phrase[0]]]

                    if(len(init) == 0):
                        for i in range(0, len(sceneId)):
                            init.append([sceneId[i], pos[i]])

                    for i in range(1, len(phrase)):
                        curr = []
                        sceneId = [p.sceneId for p in invertedIndex[phrase[i]]]
                        pos = [p.pos for p in invertedIndex[phrase[i]]]

                        for index in range(0, len(sceneId)):
                            curr.append([sceneId[index], pos[index]-i])
                            
                        init = set([(i[0], i[1]) for i in init]) & set([(i[0], i[1]) for i in curr])

                    list = [i[0] for i in init]
                    
                    if(len(prev) == 0):
                        prev = list
                    else:
                        prev = [i for i in prev if i in list] 
                else:
                    list = invertedIndex[term]
                    for i in range(0, len(list)):
                        if(list[i].sceneId not in ret):
                            ret.append(list[i].sceneId)
        elif(AndOr == "and"):
            prev = []
            for term in terms:
                if(len(term.split(" ")) > 1):                    
                    init = []
                    phrase = term.split(" ")
                    sceneId = [p.sceneId for p in invertedIndex[phrase[0]]]
                    pos = [p.pos for p in invertedIndex[phrase[0]]]

                    if(len(init) == 0):
                        for i in range(0, len(sceneId)):
                            init.append([sceneId[i], pos[i]])

                    for i in range(1, len(phrase)):
                        curr = []
                        sceneId = [p.sceneId for p in invertedIndex[phrase[i]]]
                        pos = [p.pos for p in invertedIndex[phrase[i]]]

                        for index in range(0, len(sceneId)):
                            curr.append([sceneId[index], pos[index]-i])
                            
                        init = set([(i[0], i[1]) for i in init]) & set([(i[0], i[1]) for i in curr])

                    list = [i[0] for i in init]
                    
                    if(len(prev) == 0):
                        prev = list
                    else:
                        prev = [i for i in prev if i in list] 
                else:
                    list = [i.sceneId for i in invertedIndex[term]]
                    if(len(prev) == 0):
                        prev = list
                    else:
                        prev = [i for i in prev if i in list]
            for item in prev:
                if(item not in ret):
                    ret.append(item)
    ret.sort()
    return ret

def query(invertedIndex, queriesFile, outputFolder):
    file = open(queriesFile, "r", encoding="utf-8")
    queries = file.read().split("\n")
    file.close()

    for line in queries:
        list = line.split("\t")
        queryname = list[0]
        playscene = list[1]
        AndOr  = list[2]
        ret = []

        for i in range(3, len(list)):
            ret.append(list[i])
        

        newList = process_query(invertedIndex, playscene, AndOr, ret)
        out = os.path.join(outputFolder, queryname + ".txt")
        file = open(out, "w", encoding="utf-8")
        
        for item in newList:
            file.write(item)
            file.write("\n")
        file.close()

if __name__ == '__main__':
    # Read arguments from command line, or use sane defaults for IDE.
    argv_len = len(sys.argv)
    inputFile = sys.argv[1] if argv_len >= 2 else 'shakespeare-scenes.json.gz'
    queriesFile = sys.argv[2] if argv_len >= 3 else 'trainQueries.tsv'
    outputFolder = sys.argv[3] if argv_len >= 4 else 'results/'
    if not os.path.isdir(outputFolder):
        os.mkdir(outputFolder)
    
    inverted = indexer(inputFile)
    query(inverted, queriesFile, outputFolder)